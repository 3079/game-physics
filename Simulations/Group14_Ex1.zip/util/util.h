#ifndef __util_h__
#define __util_h__


#include <string>


std::wstring GetExePath();

void UpdateWindowTitle(const std::wstring& appName);


#endif
